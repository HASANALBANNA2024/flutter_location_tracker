import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';

/// অ্যাপের সব fixed মান (constant) এক জায়গায় রাখা হয়েছে,
/// যাতে পরে কিছু বদলাতে হলে শুধু এই ফাইল এডিট করলেই হয়।
class AppConstants {
  AppConstants._();

  static const String appTitle = 'Real-Time Location Tracker';

  /// Marker-এ tap করলে যে info bubble-এর title দেখাবে
  static const String infoTitle = 'My current location';

  /// Location refresh interval (assignment requirement: প্রতি ১০ সেকেন্ডে)
  static const Duration updateInterval = Duration(seconds: 10);

  // ---------------- Map settings ----------------

  static const double defaultZoom = 16;
  static const double minZoom = 3;
  static const double maxZoom = 19;

  /// Camera smooth করে এক জায়গা থেকে আরেক জায়গায় যেতে কত সময় নেবে
  static const Duration cameraAnimationDuration = Duration(milliseconds: 800);

  /// OpenStreetMap-এর ফ্রি tile server (কোনো API key লাগে না)
  static const String tileUrlTemplate =
      'https://tile.openstreetmap.org/{z}/{x}/{y}.png';

  /// OSM-এর নিয়ম অনুযায়ী অ্যাপের package name দিতে হয়।
  /// তোমার android applicationId আলাদা হলে এখানে সেটা বসিয়ে দাও।
  static const String userAgentPackageName =
      'com.example.real_time_location_tracker';

  /// প্রথম GPS fix আসার আগ পর্যন্ত এই জায়গা দেখাবে (ঢাকা)
  static const LatLng fallbackPosition = LatLng(23.7216771, 90.4165835);

  // ---------------- Polyline ----------------

  static const Color polylineColor = Colors.blue;
  static const double polylineWidth = 5;

  // ---------------- Marker ----------------

  static const Color markerColor = Colors.red;
  static const double markerIconSize = 44;

  /// Marker-এর box-এর সাইজ। এর ভেতরেই pin icon + info bubble বসে।
  static const double markerWidth = 240;
  static const double markerHeight = 130;
}
