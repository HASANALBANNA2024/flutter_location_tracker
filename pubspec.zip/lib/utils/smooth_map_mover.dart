import 'package:flutter/animation.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import 'constants.dart';

/// Google Map-এর `animateCamera()`-এর বিকল্প।
///
/// flutter_map-এর `MapController.move()` camera-কে সরাসরি লাফ দিয়ে নিয়ে যায়।
/// তাই এখানে একটা AnimationController দিয়ে কয়েক ধাপে (প্রতি frame-এ)
/// center আর zoom একটু একটু করে বদলানো হয়েছে, ফলে camera smooth করে যায়।
///
/// কোনো extra package লাগেনি - শুধু Flutter-এর নিজস্ব animation ব্যবহার করা হয়েছে।
class SmoothMapMover {
  SmoothMapMover({
    required TickerProvider vsync,
    required MapController mapController,
  })  : _map = mapController,
        _animation = AnimationController(
          vsync: vsync,
          duration: AppConstants.cameraAnimationDuration,
        ) {
    // প্রতিটা frame-এ _onTick() চলবে
    _animation.addListener(_onTick);
  }

  final MapController _map;
  final AnimationController _animation;

  // animation শুরুর আর শেষের মান
  LatLng _fromCenter = AppConstants.fallbackPosition;
  LatLng _toCenter = AppConstants.fallbackPosition;
  double _fromZoom = AppConstants.defaultZoom;
  double _toZoom = AppConstants.defaultZoom;

  /// বর্তমান camera position থেকে [target] এবং [zoom]-এ smooth করে যাও।
  void moveTo(LatLng target, double zoom) {
    final camera = _map.camera; // map-এর এখনকার অবস্থা

    _fromCenter = camera.center;
    _fromZoom = camera.zoom;
    _toCenter = target;
    _toZoom = zoom;

    // শুরু থেকে animation চালাও (আগেরটা চললে সেটা থামিয়ে নতুনটা শুরু হবে)
    _animation.forward(from: 0);
  }

  /// প্রতি frame-এ একটু করে camera সরানো হয়
  void _onTick() {
    // easeInOut: শুরুতে আস্তে, মাঝে দ্রুত, শেষে আবার আস্তে
    final t = Curves.easeInOut.transform(_animation.value);

    final lat = _lerp(_fromCenter.latitude, _toCenter.latitude, t);
    final lng = _lerp(_fromCenter.longitude, _toCenter.longitude, t);
    final zoom = _lerp(_fromZoom, _toZoom, t);

    _map.move(LatLng(lat, lng), zoom);
  }

  /// a থেকে b-এর মাঝামাঝি মান বের করে (t = 0 হলে a, t = 1 হলে b)
  double _lerp(double a, double b, double t) => a + (b - a) * t;

  void dispose() {
    _animation.removeListener(_onTick);
    _animation.dispose();
  }
}
