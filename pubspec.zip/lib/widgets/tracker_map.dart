import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../utils/constants.dart';
import 'location_marker.dart';

/// শুধু UI widget: দেওয়া location আর path অনুযায়ী ম্যাপ আঁকে।
/// (আগে GoogleMap ছিল, এখন flutter_map + OpenStreetMap)
class TrackerMap extends StatelessWidget {
  const TrackerMap({
    super.key,
    required this.mapController,
    required this.current,
    required this.path,
    required this.showInfo,
    required this.onMapReady,
    required this.onMarkerTap,
    required this.onMapTap,
  });

  final MapController mapController;

  /// এখনকার location (GPS fix আসার আগে null)
  final LatLng? current;

  /// এ পর্যন্ত যে যে জায়গা দিয়ে গেছে - polyline এটা দিয়েই আঁকা হয়
  final List<LatLng> path;

  final bool showInfo;
  final VoidCallback onMapReady;
  final VoidCallback onMarkerTap;
  final VoidCallback onMapTap;

  @override
  Widget build(BuildContext context) {
    final pos = current;

    return FlutterMap(
      mapController: mapController,
      options: MapOptions(
        initialCenter: AppConstants.fallbackPosition,
        initialZoom: AppConstants.defaultZoom,
        minZoom: AppConstants.minZoom,
        maxZoom: AppConstants.maxZoom,
        // সব gesture চালু, শুধু rotate বন্ধ (compass লাগছে না)
        interactionOptions: const InteractionOptions(
          flags: InteractiveFlag.all & ~InteractiveFlag.rotate,
        ),
        onMapReady: onMapReady,
        onTap: (tapPosition, point) => onMapTap(),
      ),
      children: [
        // 1) নিচের map tile (OpenStreetMap)
        TileLayer(
          urlTemplate: AppConstants.tileUrlTemplate,
          userAgentPackageName: AppConstants.userAgentPackageName,
          maxZoom: AppConstants.maxZoom,
        ),

        // 2) নীল polyline: আগের position -> এখনকার position
        //    কমপক্ষে ২টা point না হলে লাইন আঁকা যায় না
        if (path.length >= 2)
          PolylineLayer(
            polylines: [
              Polyline(
                points: path,
                color: AppConstants.polylineColor,
                strokeWidth: AppConstants.polylineWidth,
              ),
            ],
          ),

        // 3) এখনকার location-এর marker (+ info bubble)
        if (pos != null)
          MarkerLayer(
            markers: [
              Marker(
                point: pos,
                width: AppConstants.markerWidth,
                height: AppConstants.markerHeight,
                // pin-এর ডগা ঠিক GPS point-এর উপরে বসানোর জন্য
                alignment: Alignment.topCenter,
                child: LocationMarker(
                  showInfo: showInfo,
                  snippet: '${pos.latitude.toStringAsFixed(7)},'
                      '${pos.longitude.toStringAsFixed(7)}',
                  onTap: onMarkerTap,
                ),
              ),
            ],
          ),

        // 4) OpenStreetMap-এর license অনুযায়ী credit দেখানো বাধ্যতামূলক
        //    (নিচের বাম কোণে, কারণ ডানে FAB আছে)
        RichAttributionWidget(
          alignment: AttributionAlignment.bottomLeft,
          attributions: [
            TextSourceAttribution('OpenStreetMap contributors'),
          ],
        ),
      ],
    );
  }
}
