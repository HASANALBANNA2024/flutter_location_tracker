import 'package:flutter/material.dart';

/// Google Map-এর "info window"-এর মতো ছোট বাবল।
/// flutter_map-এ info window নেই, তাই নিজেরা বানানো হয়েছে।
/// উপরে title, নিচে snippet (lat,lng) দেখায়।
class InfoBubble extends StatelessWidget {
  const InfoBubble({
    super.key,
    required this.title,
    required this.snippet,
  });

  final String title;
  final String snippet;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // মূল বাবল
        Material(
          elevation: 4,
          color: Colors.white,
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  snippet,
                  style: const TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ],
            ),
          ),
        ),
        // নিচের ছোট তীর (marker-এর দিকে ইশারা)
        const Icon(Icons.arrow_drop_down, color: Colors.white, size: 24),
      ],
    );
  }
}
