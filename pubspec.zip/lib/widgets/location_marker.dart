import 'package:flutter/material.dart';

import '../utils/constants.dart';
import 'info_bubble.dart';

/// Map-এর উপর যে marker দেখায়: নিচে লাল pin, উপরে (চাইলে) info bubble।
///
/// এই widget-টা flutter_map-এর `Marker`-এর child হিসেবে বসে।
/// Marker-এর `alignment: Alignment.topCenter` দেওয়া আছে, তাই
/// এই box-এর নিচের মাথা (pin-এর ডগা) ঠিক GPS point-এর উপর থাকে।
class LocationMarker extends StatelessWidget {
  const LocationMarker({
    super.key,
    required this.showInfo,
    required this.snippet,
    required this.onTap,
  });

  /// info bubble দেখাবে কিনা
  final bool showInfo;

  /// bubble-এর নিচের লাইন, যেমন "23.7216771,90.4165835"
  final String snippet;

  /// marker-এ tap করলে কী হবে
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Align(
        // সবসময় নিচে থাকবে, যাতে bubble আসা-যাওয়ায় pin নড়ে না
        alignment: Alignment.bottomCenter,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (showInfo)
              InfoBubble(title: AppConstants.infoTitle, snippet: snippet),
            const Icon(
              Icons.location_on,
              color: AppConstants.markerColor,
              size: AppConstants.markerIconSize,
            ),
          ],
        ),
      ),
    );
  }
}
