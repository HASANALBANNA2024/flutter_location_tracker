# Real-Time Location Tracker (Flutter)

Google Maps + Geolocator assignment.

## Features
1. **Automatic map animation** – camera smoothly animates to the user's location.
2. **Real-time updates** – location fetched every **10 seconds**, marker moves.
3. **Polyline tracking** – blue line connects previous -> current positions.
4. **Marker info window** – tap marker: title `My current location`, snippet = `lat,lng`.

## Project structure
```
lib/
├── main.dart                      # entry point
├── app.dart                       # MaterialApp
├── utils/constants.dart           # interval, zoom, ids, colors
├── services/location_service.dart # Geolocator + permission handling
├── controllers/tracker_controller.dart # state, timer, marker, polyline, camera
├── screens/tracker_screen.dart    # screen
└── widgets/
    ├── tracker_app_bar.dart
    ├── tracker_map.dart
    ├── error_banner.dart
    └── loading_overlay.dart
```

## Setup (one time)

This repo contains the Dart code. Generate the platform folders first:

```bash
cd real_time_location_tracker
flutter create . --project-name real_time_location_tracker --platforms=android,ios
flutter pub get
```
(Existing `lib/` and `pubspec.yaml` are kept.)

### 1. Get a Google Maps API key
Google Cloud Console -> enable **Maps SDK for Android** (and iOS) -> create API key.

### 2. Android
`android/app/src/main/AndroidManifest.xml` - put inside `<manifest>` (before `<application>`):
```xml
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>
<uses-permission android:name="android.permission.INTERNET"/>
```
and inside `<application>`:
```xml
<meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="YOUR_API_KEY_HERE"/>
```
`android/app/build.gradle(.kts)`: make sure `minSdk` is at least **21** (`minSdk = 21` or `flutter.minSdkVersion`).

### 3. iOS (optional)
`ios/Runner/Info.plist`:
```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>This app needs your location to show it on the map.</string>
```
`ios/Runner/AppDelegate.swift`: `import GoogleMaps` and in `didFinishLaunchingWithOptions` add `GMSServices.provideAPIKey("YOUR_API_KEY_HERE")`.

## Run
```bash
flutter run
```
On the emulator: Extended controls (...) -> Location -> set a route/point to see movement.
On a real phone: walk around - the polyline grows every 10 seconds.

## Submission
Push to GitHub (do **not** commit your real API key - replace it with a placeholder).
```bash
git init
git add .
git commit -m "Real-time location tracker"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```
