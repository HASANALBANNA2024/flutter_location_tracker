import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../services/location_service.dart';
import '../utils/constants.dart';

/// Holds all tracking state: marker, polyline, timer and map animation.
class TrackerController extends ChangeNotifier {
  TrackerController({LocationService? service})
      : _service = service ?? LocationService();

  final LocationService _service;

  GoogleMapController? _mapController;
  Timer? _timer;
  bool _disposed = false;

  final List<LatLng> _path = [];
  LatLng? _current;
  String? _error;
  bool _permanentlyDenied = false;
  bool _loading = true;
  bool _firstFix = true;

  // ---- getters used by the UI ----
  LatLng? get current => _current;
  String? get error => _error;
  bool get permanentlyDenied => _permanentlyDenied;
  bool get loading => _loading;

  Set<Marker> get markers {
    final pos = _current;
    if (pos == null) return {};
    return {
      Marker(
        markerId: const MarkerId(AppConstants.markerId),
        position: pos,
        infoWindow: InfoWindow(
          title: AppConstants.infoTitle,
          snippet: '${pos.latitude.toStringAsFixed(7)},'
              '${pos.longitude.toStringAsFixed(7)}',
        ),
      ),
    };
  }

  Set<Polyline> get polylines {
    if (_path.length < 2) return {};
    return {
      Polyline(
        polylineId: const PolylineId(AppConstants.polylineId),
        points: List<LatLng>.from(_path),
        color: AppConstants.polylineColor,
        width: AppConstants.polylineWidth,
      ),
    };
  }

  // ---- lifecycle ----
  void onMapCreated(GoogleMapController controller) {
    _mapController = controller;
    final pos = _current;
    if (pos != null) _animateTo(pos);
  }

  Future<void> start() async {
    _timer?.cancel();
    _loading = true;
    _error = null;
    _notify();

    try {
      await _service.ensureReady();
    } on LocationException catch (e) {
      _error = e.message;
      _permanentlyDenied = e.permanentlyDenied;
      _loading = false;
      _notify();
      return;
    }

    await _fetchLocation(); // first fix immediately
    _timer = Timer.periodic(AppConstants.updateInterval, (_) => _fetchLocation());
  }

  Future<void> _fetchLocation() async {
    try {
      final p = await _service.getCurrentPosition();
      final pos = LatLng(p.latitude, p.longitude);

      _current = pos;
      _path.add(pos); // previous -> current gets connected by the polyline
      _error = null;
      _loading = false;
      _notify();

      await _animateTo(pos);

      if (_firstFix) {
        _firstFix = false;
        _showInfoWindow();
      }
    } catch (e) {
      _error = 'Could not get location: $e';
      _loading = false;
      _notify();
    }
  }

  Future<void> _animateTo(LatLng pos) async {
    await _mapController?.animateCamera(
      CameraUpdate.newLatLngZoom(pos, AppConstants.defaultZoom),
    );
  }

  void _showInfoWindow() {
    _mapController?.showMarkerInfoWindow(
      const MarkerId(AppConstants.markerId),
    );
  }

  Future<void> goToMyLocation() async {
    final pos = _current;
    if (pos != null) await _animateTo(pos);
  }

  Future<void> openSettings() => _permanentlyDenied
      ? _service.openAppSettings()
      : _service.openLocationSettings();

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    _mapController?.dispose();
    super.dispose();
  }
}
