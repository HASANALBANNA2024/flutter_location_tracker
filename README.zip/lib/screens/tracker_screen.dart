import 'package:flutter/material.dart';

import '../controllers/tracker_controller.dart';
import '../widgets/error_banner.dart';
import '../widgets/loading_overlay.dart';
import '../widgets/tracker_app_bar.dart';
import '../widgets/tracker_map.dart';

class TrackerScreen extends StatefulWidget {
  const TrackerScreen({super.key});

  @override
  State<TrackerScreen> createState() => _TrackerScreenState();
}

class _TrackerScreenState extends State<TrackerScreen> {
  final TrackerController _controller = TrackerController();

  @override
  void initState() {
    super.initState();
    _controller.start();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const TrackerAppBar(),
      body: ListenableBuilder(
        listenable: _controller,
        builder: (context, _) {
          return Stack(
            children: [
              TrackerMap(
                markers: _controller.markers,
                polylines: _controller.polylines,
                onMapCreated: _controller.onMapCreated,
              ),
              if (_controller.loading)
                const Positioned(
                  top: 16,
                  left: 0,
                  right: 0,
                  child: Center(child: LoadingOverlay()),
                ),
              if (_controller.error != null)
                Positioned(
                  top: 16,
                  left: 16,
                  right: 16,
                  child: ErrorBanner(
                    message: _controller.error!,
                    onRetry: _controller.start,
                    onOpenSettings: _controller.openSettings,
                  ),
                ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _controller.goToMyLocation,
        child: const Icon(Icons.my_location),
      ),
    );
  }
}
