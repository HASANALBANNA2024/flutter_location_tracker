import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class AppConstants {
  AppConstants._();

  static const String appTitle = 'Real-Time Location Tracker';
  static const String markerId = 'current_location_marker';
  static const String polylineId = 'tracking_polyline';
  static const String infoTitle = 'My current location';

  /// Location refresh interval (task requirement: every 10 seconds)
  static const Duration updateInterval = Duration(seconds: 10);

  static const double defaultZoom = 16;

  /// Shown only until the first GPS fix arrives (Dhaka)
  static const LatLng fallbackPosition = LatLng(23.7216771, 90.4165835);

  static const Color polylineColor = Colors.blue;
  static const int polylineWidth = 5;
}
