import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../utils/constants.dart';

/// Pure UI widget: draws the map with the given markers and polylines.
class TrackerMap extends StatelessWidget {
  const TrackerMap({
    super.key,
    required this.markers,
    required this.polylines,
    required this.onMapCreated,
  });

  final Set<Marker> markers;
  final Set<Polyline> polylines;
  final void Function(GoogleMapController) onMapCreated;

  @override
  Widget build(BuildContext context) {
    return GoogleMap(
      initialCameraPosition: const CameraPosition(
        target: AppConstants.fallbackPosition,
        zoom: AppConstants.defaultZoom,
      ),
      onMapCreated: onMapCreated,
      markers: markers,
      polylines: polylines,
      zoomControlsEnabled: true,
      myLocationButtonEnabled: false,
      compassEnabled: true,
    );
  }
}
